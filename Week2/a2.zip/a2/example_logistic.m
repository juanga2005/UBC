
load logisticData.mat
tic
model = logisticL2(X,y,1);
toc